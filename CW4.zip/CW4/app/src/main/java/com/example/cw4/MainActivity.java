package com.example.cw4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText x = findViewById(R.id.editTextTextPersonName);
        final EditText y = findViewById(R.id.editTextTextPersonName3);
        Button e = findViewById(R.id.button);
        Button c = findViewById(R.id.button4);
        Button u = findViewById(R.id.button5);

        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(x.getText().toString());
                int b = Integer.parseInt(y.getText().toString());
                int amal = a + b;
                Toast.makeText(MainActivity.this, amal +"", Toast.LENGTH_SHORT).show();
            }
        });

        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int h = Integer.parseInt(x.getText().toString());
                int g = Integer.parseInt(y.getText().toString());
                int joury = h * g;
                Toast.makeText(MainActivity.this, joury +"", Toast.LENGTH_SHORT).show();
            }
        });

        u.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int o = Integer.parseInt(x.getText().toString());
                int p = Integer.parseInt(y.getText().toString());
                int tea = o/p;
                Toast.makeText(MainActivity.this, tea +"", Toast.LENGTH_SHORT).show();
            }
        });

    }
}